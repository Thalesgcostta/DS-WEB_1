import React from 'react'
import img from '../assets/easter-egg.png' //Importei a imagem easter egg para ser utilizada na div 
import Toolbar from '@mui/material/Toolbar'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'
import api from '../lib/api'

export default function StartPage() {
    //Criei a váriavel de estado
    const [state, setState] = React.useState({about: '', imgVisible: false })
    //Logo abaixo foi criado as váriaveis avulsas usando desestruturação
    const {about, imgVisible} = state
    
    //Criei um hook useEffect 
    React.useEffect(() => {
        fetchData() //Efetuei uma chamada à função fetchData()
    }, [])

    async function fetchData(newState = state) {
        try {
            const response = await api.get('/sobre/1')
            //Atualizei apenas o campo about do state com o valor de response.data
            setState({...newState, about: response.data})
        }
        catch(erro) {
            alert('ERRO: ' + erro.message)
        }
    }

    return (

        <>
            <h1>Sobre o projeto Karangos</h1>

            <div dangerouslySetInnerHTML={{__html: about.info}} />

            <Box sx={{ textAlign: 'center' }}>
                <Toolbar sx={{ justifyContent: 'space-around' }}>
                    <Button
                        color="secondary"
                        variant="contained"
                        onClick={() => {
                            //Atualizei o imgVisible da variavel de estado, assim quando o usuário clicar no botão a imagem será mostrada.
                            setState(prevState => ({...prevState, imgVisible: true}))
                        }}
                    >
                        Surpresa!
                    </Button>
                </Toolbar>
                <img alt="Carros antigos" style={{ 
                    display: 'block',
                    margin: '0 auto',
                    transition: 'opacity 1s linear',
                    opacity: imgVisible ? '1' : '0', 
                    height: imgVisible ? '591px': '0'
                }} src={img} /> {/* Utilizei a imagem importada dentro da tag <img> */}
            </Box>
        </>
    )
}